import React, { Component } from 'react';
import './App.css';
import MovieCard from './MovieCard';
import axios from 'axios';
import Carousal from './Carousal';

import {
  Jumbotron,
  Alert,
  Container,
  Row,
  Col,
  Form,
  FormGroup,
  Label,
  Input
} from 'reactstrap';

class App extends Component {
  constructor() {
    super();
    this.state = {
      alertVisible: false,
      alertVisible_addedSuccess: false,
      alertVisible_DeleteSuccess: false,
      title: '',
      movies: []
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.onDismiss = this.onDismiss.bind(this);
  }

  //for popup
  onDismiss() {
    this.setState({ alertVisible: false });
  }

  getAllMovies = () => {
    axios
      .get(' https://whispering-cliffs-79823.herokuapp.com/getallmovies')
      .then(result => {
        this.setState({ movies: result.data });
      })
      .catch(error => {
        console.log(error);
      });
  };

  componentDidMount() {
    this.getAllMovies();
  }

  //for form
  onSubmit = e => {
    e.preventDefault();
    this.setState({ alertVisible: false });

    const query = `https://whispering-cliffs-79823.herokuapp.com/getmovie?title=${
      this.state.title
    }`;

    console.log(query);

    axios
      .get(query)
      .then(result => {
        console.log(result.data);
        if (result.data === 'Not found') {
          this.setState({ alertVisible: true });
        } else {
          this.setState({ alertVisible_addedSuccess: true });
          setTimeout(() => {
            this.setState({ alertVisible_addedSuccess: false });
          }, 2000);

          this.getAllMovies();
        }
      })
      .catch(error => {
        this.setState({ alertVisible: true });
        setTimeout(() => {
          this.setState({ alertVisible: false });
        }, 2000);
      });
  };

  // for form field
  onChange(e) {
    this.setState({
      [e.target.name]: e.target.value
    });
  }

  removeMovie(title) {
    this.setState({
      movies: this.state.movies.filter(movie => {
        if (movie.title !== title) return movie;
      })
    });
    const query = `https://whispering-cliffs-79823.herokuapp.com//deletemovie?title=${title}`;
    axios
      .get(query)
      .then(result => {
        console.log(result);

        this.setState({ alertVisible_DeleteSuccess: true });
        setTimeout(() => {
          this.setState({ alertVisible_DeleteSuccess: false });
        }, 2000);

        this.getAllMovies();
      })
      .catch(error => {
        alert('Error: ', error);
      });
  }

  render() {
    let movieCards = this.state.movies.map(movie => {
      return (
        <Col sm="3" key={movie.title}>
          <MovieCard removeMovie={this.removeMovie.bind(this)} movie={movie} />
        </Col>
      );
    });
    return (
      <div className="App">
        <br />
        <Container>
          <Jumbotron id="jumboheader">
            <h1
              class
              style={{
                padding: '20px',
                color: '#f9f9f9'
              }}
            >
              <strong>
                <i>Movies & Chills</i>
              </strong>
            </h1>
          </Jumbotron>
          <Carousal id="jumboheader" />
          <Row>
            <Col>
              <Alert
                color="danger"
                isOpen={this.state.alertVisible}
                toggle={this.onDismiss}
              >
                Movie are not found or not available
              </Alert>
              <Alert
                color="success"
                isOpen={this.state.alertVisible_addedSuccess}
                toggle={this.onDismiss}
              >
                Movie Successfully Added
              </Alert>

              <Alert
                color="danger"
                isOpen={this.state.alertVisible_DeleteSuccess}
                toggle={this.onDismiss}
              >
                Movie Successfully Deleted
              </Alert>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form onSubmit={this.onSubmit}>
                <FormGroup>
                  <Label
                    for="title"
                    style={{
                      color: '#f9f9f9',
                      size: '40px'
                    }}
                  >
                    <strong>
                      <i> Enter the movie title</i>
                    </strong>
                  </Label>
                  <Input
                    type="text"
                    name="title"
                    id="title"
                    placeholder="Enter the movie title"
                    onChange={this.onChange}
                  />
                </FormGroup>
                <button type="submit" class="btn btn-info">
                  <i class="fa fa-database" />
                  Search movie
                </button>
              </Form>
            </Col>
          </Row>

          <p />
          <Row>{movieCards}</Row>
        </Container>
      </div>
    );
  }
}

export default App;
